#include <stdio.h>

#define K 10000

int main()
{
	int i;
	
	freopen("INPUT.txt", "w", stdout);
	
	printf("%d\n", K);
	for (i = 0; i < K; i++) printf("%d\n", i + 1);
	for (i = 0; i < K; i++) printf("%d\n", i + 1);
	return 0;
}
