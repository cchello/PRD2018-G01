#include <stdio.h>
#include <time.h>
#include <stdlib.h>
#define K 10000

int main()
{
	int i, tmp, total;
	int flag[100001];
	
	freopen("INPUT.txt", "w", stdout);

	srand((int)time(0)); 
	
	printf("%d\n", K);

	for (i = 1; i <= K; i++) flag[i] = 0;
	total = 0;
	while (total < K)
	{ 
		tmp = 1+(int)(K*1.0*rand()/(RAND_MAX+1.0));
		if (flag[tmp] == 0) {
			flag[tmp] = 1;
			total++;
			printf("%d\n", tmp);
		}
	} 

	for (i = 1; i <= K; i++) flag[i] = 0;
	total = 0;
	while (total < K)
	{ 
		tmp = 1+(int)(K*1.0*rand()/(RAND_MAX+1.0));
		if (flag[tmp] == 0) {
			flag[tmp] = 1;
			total++;
			printf("%d\n", tmp);
		}
	}
	return 0;
}
