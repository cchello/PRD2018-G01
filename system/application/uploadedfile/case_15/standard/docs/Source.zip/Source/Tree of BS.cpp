#include <stdio.h>
#include <stdlib.h>
#include <memory.h>
#include <time.h>

struct TreeNode;
typedef struct TreeNode *Position;
typedef struct TreeNode *SearchTree;

struct TreeNode
{
    int Element;
    SearchTree Left;
    SearchTree Right;
};

SearchTree MakeEmpty(SearchTree T)
{
    if (T != NULL)
    {
        MakeEmpty(T->Left);
        MakeEmpty(T->Right);
        free(T);
    }
    return NULL;
}

Position Find(int X, SearchTree T)
{
    if (T == NULL) return NULL;
    if (X < T->Element) return Find(X, T->Left);
    else if (X > T->Element) Find(X, T->Right);
    else return T;
}

Position FindMin(SearchTree T)
{
    if (T != NULL)
        while (T->Left != NULL)
            T = T->Left;

    return T;
}

Position FindMax(SearchTree T)
{
    if (T != NULL)
        while (T->Right != NULL)
            T = T->Right;

    return T;
}

SearchTree Insert(int X, SearchTree T)
{
    if (T == NULL)
    {
        /*Creater and return a one-node tree*/
        T = (TreeNode *)malloc(sizeof (struct TreeNode));
        T->Element = X;
        T->Left = T->Right = NULL;
    }
    else if (X < T->Element)
        T->Left = Insert(X, T->Left);
    else if (X > T->Element)
        T->Right = Insert(X, T->Right);
    /*For the reason that all the Xs are distinct, so there'll be no situation that X == T->Element*/

    return T;
    /*Do not forget this line!!*/
}

SearchTree Delete(int X, SearchTree T)
{
    Position TmpCell;

    if (T == NULL) printf("NOT FOUND!\n");
    else if (X < T->Element)    /*Go left*/
    {
        T->Left = Delete(X, T->Left);
    }
    else if (X > T->Element)    /*Go right*/
    {
        T->Right = Delete(X, T->Right);
    }
    else  /*Found element to be deleted*/
        if (T->Left && T->Right)    /*Two children*/
        {
            /*Replace with smallest in right subtree*/
            TmpCell = FindMin(T->Right);
            T->Element = TmpCell->Element;
            T->Right = Delete(T->Element, T->Right);
        }
        else    /*One or Zero children*/
        {
            TmpCell = T;
            if (T->Left == NULL)  /*Also handles 0 children*/
                T = T->Right;
            else if (T->Right == NULL)
                T = T->Left;
            free (TmpCell);
        }

    return T;
}

int main ()
{
    int N, i, X;
    SearchTree BSTree;
    
	clock_t start, stop;   /* The variable start and stop are defined as built-in type here to record the starting and ending time */
	double total_time;     /* The variable duration is used to record the lasting time the tested program runs per time, as the total_time records the lasting time the tested program runs for Repeat_times times */ 


	freopen("INPUT.txt", "r", stdin);

	start = clock();
	
    scanf("%d", &N);
    BSTree = NULL;
    for (i = 0; i < N; i++)
    {
        scanf("%d", &X);
        BSTree = Insert(X, BSTree);
    }
    for (i = 0; i < N; i++)
    {
        scanf("%d", &X);
        BSTree = Delete(X, BSTree);
    }
    
    stop = clock();
	total_time = ((double)(stop - start)) / CLK_TCK;       /* Calculate the total time */
	printf("The total time is %lf seconds\n", total_time); /* Print out the total time and the duration */
    return 0;
}
