#include <stdio.h>
#include <stdlib.h>
#include <time.h>

  #ifndef _Splay_H
  typedef int ElementType;
  struct SplayNode;
  typedef struct SplayNode *SplayTree;
  typedef struct SplayNode *Position;
  
  Position Find( ElementType X, SplayTree *T );
  SplayTree Insert( ElementType X, SplayTree T );
  SplayTree Delete( ElementType X, SplayTree T ); 
  void PrintTree(SplayTree T);
  #endif
  struct SplayNode{
     ElementType Element;
     SplayTree Left;
     SplayTree Right;
     }; 

  SplayTree MakeEmpty( SplayTree T )
  {
	if (T != NULL) {
		MakeEmpty(T->Left);
		MakeEmpty(T->Right);
		free(T);
	}
	return NULL;
  }

  SplayTree SingleRotateWithLeft( SplayTree T )  /*routine to fix case 1*/
  { 
	SplayTree x = T;
	SplayTree y = T->Left;
	x->Left = y->Right;
	y->Right = x;
	return y;
  }

  SplayTree SingleRotateWithRight( SplayTree T ) /*routine to fix case 4*/
  {
	SplayTree x = T;
	SplayTree y = T->Right;
    x->Right = y->Left;
	y->Left = x;
	return y;
  }

  SplayTree DoubleRotateWithLeft( SplayTree T )  /*routine to fix case 2*/
  {
	T->Left = SingleRotateWithRight( T->Left );
	return SingleRotateWithLeft( T );
  }

  SplayTree DoubleRotateWithRight( SplayTree T ) /*routine to fix case 3*/
  {
	T->Right = SingleRotateWithLeft( T->Right );
	return SingleRotateWithRight( T );
  }

  Position Find( ElementType X, SplayTree * T ) /*Find element x and fix splaytree's property*/
  {
	static int deepth = -1;              
	Position P = NULL;
	deepth++;
	
	if ( (*T) == NULL )  /*if the tree is empty,return NULL*/
    {
	  deepth = -1;
	  return NULL;
	}
	
	if ( X < (*T)->Element ) 
    {
	  P= Find( X, &((*T)->Left) ); /*find x in the left subtree of T*/
	  if ( P == NULL )     /*if x is not found,return NULL*/
        return NULL;
	  if ( P == (*T)->Left ) 
      {
	    if ( deepth == 0)  /*if x's father is root,rotate the two directly*/
          (*T) = SingleRotateWithLeft( (*T) );
        else 
        { deepth--;
	      return P;}
      } 
      else if ( P == (*T)->Left->Left ) /*in the case of zig-zig,do SingleRotateWithLeft twice */
      {     
        (*T) = SingleRotateWithLeft( (*T) );
	    (*T) = SingleRotateWithLeft( (*T) );	
	  } 
      else if ( P == (*T)->Left->Right )  /*in the case of zig-zag,do DoubleRotateWithLeft */
      {
	    (*T) = DoubleRotateWithLeft( (*T) );
	  } 
	} 
    else if ( X > (*T)->Element ) 
    {
      P= Find( X, &((*T)->Right) );   /*find x in the left subtree of T*/
	  if ( P == NULL )      /*if x is not found,return NULL*/
	    return NULL;
	  if ( P == (*T)->Right ) 
      {
	    if ( deepth == 0)   /*if x's father is root,rotate the two directly*/
	      (*T) = SingleRotateWithRight( (*T) );
        else 
        {  deepth--;
	       return P;
		}
      } 
      else if ( P == (*T)->Right->Right )   /*in the case of zig-zig,do SingleRotateWithRight twice */
      {
	    (*T) = SingleRotateWithRight( (*T) );
	    (*T) = SingleRotateWithRight( (*T) );
      } 
      else if ( P== (*T)->Right->Left )     /*in the case of zig-zag,do DoubleRotateWithRight */
      {
	    (*T) = DoubleRotateWithRight( (*T) );
	  } 
	} 
	
	deepth--;
	return (*T);        
  }

  static SplayTree _insert( ElementType X, SplayTree T ) /*routine to insert an element into the tree*/
  {
	if ( T == NULL )                /*when x's position is found,creat a cell*/
    {
	  T = (SplayTree)malloc( sizeof( struct SplayNode ) );
	  T->Element = X;
	  T->Left = NULL;
	  T->Right = NULL;
	  return T;	
	}
	
	if ( X < T->Element ) 
    {
	  T->Left = Insert( X, T->Left );
	} 
    else if ( X > T->Element ) 
    {
	  T->Right = Insert( X, T->Right );
	}
	
	return T;	
  }
  
  SplayTree Insert( ElementType X, SplayTree T )
  {
	T = _insert( X, T );
	return Find( X, &T );   /*after the insertion, fix the splaytree's property*/
  } 


  SplayTree Delete( ElementType X, SplayTree T )
  { 
	SplayTree child_tree = NULL;
	
	if ( T == NULL )
	  return NULL;
		
	if ( X < T->Element )     
    {
	  T->Left = Delete( X, T->Left );
	} 
    else if ( X > T->Element ) 
    {
	  T->Right = Delete( X, T->Right );
	} 
    else 
    {
	  if ( T->Left == NULL )  /*only has right child*/
      {
        child_tree = T->Right;
	    free( T );
	    T = child_tree;
	  } 
      else if ( T->Right == NULL )   /*only has left child*/
      {
	    child_tree = T->Left;
        free( T );
	    T = child_tree;
	  } 
      else          /* when it has two children,replace with smallest in right subtree */
      {
	   SplayTree Temp;
	   SplayTree P1;
	   SplayTree P2;
	   P1 = T;
	   P2 = T->Right;
	   while ( P2->Left != NULL ) 
       {
		 P1 = P2;
	     P2 = P2->Left;
	   }
       if ( P1 != T )  /* make parent(min(T->right))->left = NULL */
       {  
	     P1->Left = NULL;
       } 
       else 
       {
	     T->Right = NULL;
	   }
       Temp = T;	/* make T=min(T->right) */
	   T = P2;
	   T->Left = Temp->Left;
	   T->Right = Temp->Right;
       free( Temp );   /*release the oringinal T,which is the element to be deleted*/
	}
  }
	
	return T;
}

int main ()
{
	int N, i, X;
	SplayTree SPLAY;
	
	clock_t start, stop;   /* The variable start and stop are defined as built-in type here to record the starting and ending time */
	double total_time;     /* The variable duration is used to record the lasting time the tested program runs per time, as the total_time records the lasting time the tested program runs for Repeat_times times */ 

	
	freopen("INPUT.txt", "r", stdin);

	start = clock();
	
	scanf("%d", &N);
	SPLAY = NULL;
	for (i = 0; i < N; i++) {
		scanf("%d", &X);
		SPLAY = Insert(X, SPLAY);
	}
	for (i = 0; i < N; i++) {
		scanf("%d", &X);
		SPLAY = Delete(X, SPLAY);
	}
	
	stop = clock();
	total_time = ((double)(stop - start)) / CLK_TCK;       /* Calculate the total time */
	printf("The total time is %lf seconds\n", total_time); /* Print out the total time and the duration */
	return 0;
}


