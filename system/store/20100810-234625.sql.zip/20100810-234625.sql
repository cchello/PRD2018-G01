-- MySQL dump 10.11
--
-- Host: localhost    Database: pbclsV01
-- ------------------------------------------------------
-- Server version	5.0.51a-3ubuntu5.4

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `applications`
--

DROP TABLE IF EXISTS `applications`;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
CREATE TABLE `applications` (
  `userid` int(11) NOT NULL,
  `instanceid` int(11) NOT NULL,
  `roleid` int(11) NOT NULL,
  `isindicator` tinyint(1) NOT NULL,
  `isobserver` tinyint(1) NOT NULL,
  `applytime` timestamp NOT NULL default CURRENT_TIMESTAMP on update CURRENT_TIMESTAMP,
  `ischecked` tinyint(1) NOT NULL,
  `isaccepted` tinyint(1) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci ROW_FORMAT=COMPACT;
SET character_set_client = @saved_cs_client;

--
-- Dumping data for table `applications`
--

LOCK TABLES `applications` WRITE;
/*!40000 ALTER TABLE `applications` DISABLE KEYS */;
/*!40000 ALTER TABLE `applications` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `ban_emaillist`
--

DROP TABLE IF EXISTS `ban_emaillist`;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
CREATE TABLE `ban_emaillist` (
  `id` int(32) NOT NULL auto_increment,
  `email` varchar(255) default NULL,
  `time` datetime default NULL,
  `mark` varchar(255) default NULL,
  PRIMARY KEY  (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=25 DEFAULT CHARSET=utf8;
SET character_set_client = @saved_cs_client;

--
-- Dumping data for table `ban_emaillist`
--

LOCK TABLES `ban_emaillist` WRITE;
/*!40000 ALTER TABLE `ban_emaillist` DISABLE KEYS */;
INSERT INTO `ban_emaillist` VALUES (1,'wngmngchng@hotmail.com','2009-11-26 18:43:31','违规发言次数较多'),(4,'wsm@163.com','2009-11-30 18:46:13','没有完成任何案例'),(23,'wsn@163.com','2009-12-30 00:00:00','乱发广告！'),(24,'lys@163.com','2009-12-30 00:00:00','测试');
/*!40000 ALTER TABLE `ban_emaillist` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `ban_iplist`
--

DROP TABLE IF EXISTS `ban_iplist`;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
CREATE TABLE `ban_iplist` (
  `id` int(32) NOT NULL auto_increment,
  `ip` varchar(32) default NULL,
  `time` datetime default NULL,
  `mark` varchar(255) default NULL,
  PRIMARY KEY  (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8;
SET character_set_client = @saved_cs_client;

--
-- Dumping data for table `ban_iplist`
--

LOCK TABLES `ban_iplist` WRITE;
/*!40000 ALTER TABLE `ban_iplist` DISABLE KEYS */;
INSERT INTO `ban_iplist` VALUES (1,'10.214.29.244','2009-11-30 23:44:52','有危险嫌疑！'),(2,'10.10.0.22','2009-11-30 17:44:42','危险IP地址！'),(4,'222.205.12.222','2009-12-30 00:00:00','测试');
/*!40000 ALTER TABLE `ban_iplist` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `ban_regnamelist`
--

DROP TABLE IF EXISTS `ban_regnamelist`;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
CREATE TABLE `ban_regnamelist` (
  `id` int(32) NOT NULL auto_increment,
  `name` varchar(255) default NULL,
  `mark` varchar(255) default NULL,
  PRIMARY KEY  (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8;
SET character_set_client = @saved_cs_client;

--
-- Dumping data for table `ban_regnamelist`
--

LOCK TABLES `ban_regnamelist` WRITE;
/*!40000 ALTER TABLE `ban_regnamelist` DISABLE KEYS */;
INSERT INTO `ban_regnamelist` VALUES (4,'老师','老师是特定的指导者！'),(5,'admin','这个名称只能管理员使用！');
/*!40000 ALTER TABLE `ban_regnamelist` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `bbs_replys`
--

DROP TABLE IF EXISTS `bbs_replys`;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
CREATE TABLE `bbs_replys` (
  `uid` int(11) NOT NULL auto_increment,
  `subjectid` int(11) NOT NULL,
  `content` text collate utf8_unicode_ci NOT NULL,
  `authorid` int(11) NOT NULL,
  `submittime` timestamp NOT NULL default CURRENT_TIMESTAMP on update CURRENT_TIMESTAMP,
  PRIMARY KEY  (`uid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
SET character_set_client = @saved_cs_client;

--
-- Dumping data for table `bbs_replys`
--

LOCK TABLES `bbs_replys` WRITE;
/*!40000 ALTER TABLE `bbs_replys` DISABLE KEYS */;
/*!40000 ALTER TABLE `bbs_replys` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `bbs_subjects`
--

DROP TABLE IF EXISTS `bbs_subjects`;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
CREATE TABLE `bbs_subjects` (
  `uid` int(11) NOT NULL auto_increment,
  `title` varchar(255) collate utf8_unicode_ci NOT NULL,
  `content` text collate utf8_unicode_ci NOT NULL,
  `authorid` int(11) NOT NULL,
  `submittime` timestamp NOT NULL default CURRENT_TIMESTAMP on update CURRENT_TIMESTAMP,
  `caseid` int(11) NOT NULL,
  `clicks` int(11) NOT NULL,
  `replys` int(11) NOT NULL,
  PRIMARY KEY  (`uid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
SET character_set_client = @saved_cs_client;

--
-- Dumping data for table `bbs_subjects`
--

LOCK TABLES `bbs_subjects` WRITE;
/*!40000 ALTER TABLE `bbs_subjects` DISABLE KEYS */;
/*!40000 ALTER TABLE `bbs_subjects` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `cases`
--

DROP TABLE IF EXISTS `cases`;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
CREATE TABLE `cases` (
  `uid` int(10) unsigned NOT NULL auto_increment,
  `casename` varchar(255) collate utf8_unicode_ci NOT NULL,
  `description` text collate utf8_unicode_ci,
  `author` varchar(255) collate utf8_unicode_ci default NULL,
  `email` varchar(255) collate utf8_unicode_ci default NULL,
  `version` varchar(255) collate utf8_unicode_ci default NULL,
  `creationtime` date default NULL,
  `uploader` int(10) NOT NULL default '1',
  `uploadtime` datetime NOT NULL,
  `status` tinyint(1) NOT NULL COMMENT 'OPEN or CLOSED',
  `instances` int(10) NOT NULL COMMENT 'The numbers of instance about the case',
  `maxinstances` int(10) NOT NULL,
  `activity` int(10) unsigned NOT NULL,
  `startedinstances` int(11) NOT NULL,
  `finishedinstances` int(10) unsigned NOT NULL COMMENT 'the number of finished instances',
  `casetype` tinyint(1) NOT NULL COMMENT '0==self_study;1==teach',
  `maxplayer` int(11) NOT NULL,
  `foldername` varchar(255) collate utf8_unicode_ci NOT NULL,
  PRIMARY KEY  (`uid`)
) ENGINE=InnoDB AUTO_INCREMENT=18 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci ROW_FORMAT=DYNAMIC;
SET character_set_client = @saved_cs_client;

--
-- Dumping data for table `cases`
--

LOCK TABLES `cases` WRITE;
/*!40000 ALTER TABLE `cases` DISABLE KEYS */;
INSERT INTO `cases` VALUES (11,'软件工程教学辅助网站','项目管理与软件需求，作为软件工程当中最为重要的组成几个部分，已经引起业内人士的高度重视，项目管理和需求工程概念的提出，就是为了把软件工程化，以更有效地开发需求，开发软件并实现有效的管理。也作为一门新兴的课程在大学里开设。为了使教师能够把最新，最前沿的关于项目管理和需求工程的信息传播给学生；为了学生能够利用网络得到老师帮助；为了师生之间，同学之间能够充分交流，沟通心得。这个软件工程教学、学习、交流系统将提供这么一个平台。为教师和同学服务，也为项目管理，需求工程，统一建模等软件工程化课程的教学方法提供试验基地。','PBCLS','PBCLS@zju.edu.name','1.0','2010-01-15',1,'2010-07-05 10:54:20',0,2,0,0,0,0,0,6,'wmc'),(12,'DS_Project_1_Performance Measurement','','PBCLS','PBCLS@zju.edu.name','1.0','2010-03-02',1,'2010-07-05 14:09:19',0,0,0,0,0,0,0,3,'DS_Project_1_Performance Measurement'),(13,'DS_Project_2_Sort Poems','','PBCLS','PBCLS@zju.edu.name','1.0','2010-03-02',1,'2010-07-05 14:09:54',0,0,0,0,0,0,0,3,'DS_Project_2_Sort Poems'),(14,'DS_Project_3_Hashing','','PBCLS','PBCLS@zju.edu.name','1.0','2010-03-02',1,'2010-07-05 14:10:01',0,0,0,0,0,0,0,3,'DS_Project_3_Hashing'),(15,'ADS_Project_1  Binary Search Trees','','PBCLS','PBCLS@zju.edu.name','1.0','2010-03-02',1,'2010-07-05 14:10:56',0,0,0,0,0,0,0,3,'ADS_Project_1  Binary Search Trees'),(16,'ADS_Project_2 Population','','PBCLS','PBCLS@zju.edu.name','1.0','2010-03-02',1,'2010-07-05 14:11:05',0,0,0,0,0,0,0,3,'ADS_Project_2 Population'),(17,'ADS_Project_3 Family of B Trees','','PBCLS','PBCLS@zju.edu.name','1.0','2010-03-02',1,'2010-07-05 14:11:12',0,0,0,0,0,0,0,3,'ADS_Project_3 Family of B Trees');
/*!40000 ALTER TABLE `cases` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `chat_room`
--

DROP TABLE IF EXISTS `chat_room`;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
CREATE TABLE `chat_room` (
  `id` int(11) NOT NULL auto_increment,
  `insId` int(10) NOT NULL,
  `time` int(32) unsigned NOT NULL,
  `senderId` int(10) NOT NULL,
  `message` varchar(255) collate utf8_unicode_ci NOT NULL,
  PRIMARY KEY  (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
SET character_set_client = @saved_cs_client;

--
-- Dumping data for table `chat_room`
--

LOCK TABLES `chat_room` WRITE;
/*!40000 ALTER TABLE `chat_room` DISABLE KEYS */;
/*!40000 ALTER TABLE `chat_room` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `comments`
--

DROP TABLE IF EXISTS `comments`;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
CREATE TABLE `comments` (
  `uid` int(10) unsigned NOT NULL auto_increment,
  `cotent` text collate utf8_unicode_ci NOT NULL,
  `author` int(10) unsigned NOT NULL,
  `caseid` int(11) NOT NULL,
  `instanceid` int(11) NOT NULL,
  `posttime` timestamp NOT NULL default CURRENT_TIMESTAMP on update CURRENT_TIMESTAMP,
  PRIMARY KEY  (`uid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci ROW_FORMAT=DYNAMIC;
SET character_set_client = @saved_cs_client;

--
-- Dumping data for table `comments`
--

LOCK TABLES `comments` WRITE;
/*!40000 ALTER TABLE `comments` DISABLE KEYS */;
/*!40000 ALTER TABLE `comments` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `dependencies`
--

DROP TABLE IF EXISTS `dependencies`;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
CREATE TABLE `dependencies` (
  `caseid` int(11) NOT NULL,
  `predecessorid` int(11) NOT NULL,
  `successorid` int(11) NOT NULL,
  PRIMARY KEY  (`caseid`,`predecessorid`,`successorid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci ROW_FORMAT=COMPACT;
SET character_set_client = @saved_cs_client;

--
-- Dumping data for table `dependencies`
--

LOCK TABLES `dependencies` WRITE;
/*!40000 ALTER TABLE `dependencies` DISABLE KEYS */;
INSERT INTO `dependencies` VALUES (11,0,2),(11,2,3),(11,2,4),(11,3,5),(11,4,5),(11,5,6),(11,6,7),(11,7,10),(11,7,20),(11,10,11),(11,11,12),(11,12,14),(11,14,15),(11,14,16),(11,15,23),(11,16,17),(11,17,18),(11,18,23),(11,20,21),(11,21,22),(11,22,23),(11,23,25),(11,25,26),(11,26,27),(11,27,28),(11,28,29),(11,29,30),(11,30,31),(11,31,33),(11,33,34),(11,33,35),(11,34,36),(11,35,36),(11,36,37),(11,37,38),(11,38,39),(11,39,40),(11,40,42),(11,42,43),(11,43,44),(11,44,45),(11,45,46),(11,46,47),(11,47,50),(11,50,51),(11,51,52),(11,52,53),(11,53,55),(11,55,56),(11,56,57),(11,57,58),(11,58,59),(11,59,61),(11,61,62),(11,62,63),(11,63,64),(11,64,65),(11,65,67),(11,67,68),(11,68,69),(11,69,70),(12,0,1),(12,0,2),(12,1,3),(12,2,3),(13,0,1),(13,0,2),(13,1,3),(13,2,3),(14,0,1),(14,0,2),(14,1,3),(14,2,3),(15,0,1),(15,0,2),(15,1,3),(15,2,3),(15,3,4),(16,0,1),(16,0,2),(16,1,3),(16,2,3),(16,3,4),(17,0,1),(17,1,2),(17,2,3),(17,3,4);
/*!40000 ALTER TABLE `dependencies` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `evaluation_member`
--

DROP TABLE IF EXISTS `evaluation_member`;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
CREATE TABLE `evaluation_member` (
  `instanceid` tinyint(10) default NULL,
  `taskid` tinyint(10) default NULL COMMENT '这里的taskid应该为milestone的ID',
  `roleid` tinyint(10) default NULL,
  `userid` tinyint(10) default NULL,
  `taskstartedtime` datetime default NULL COMMENT '任务开始做的时间',
  `taskfinishedtime` datetime default NULL COMMENT '任务结束的时间',
  `duetime` tinyint(10) default NULL COMMENT '案例定义的要求完成的工期',
  `overduetime` int(10) default '0' COMMENT '在每一个milestone阶段，每个人文档超时的时间的累积',
  `workday` int(10) default '0' COMMENT '有效工作天数，每天累积超过30分钟为一个有效天数',
  `taskacceptedno` int(10) default '0' COMMENT '任务通过审核时的审核次数',
  `updownno` int(10) default '0' COMMENT '上传下载文件数量',
  `downno` int(10) default '0' COMMENT '上传文件被下载次数',
  `bbsno` int(10) default '0' COMMENT '提问或回复不同主题次数，即参与主题次数',
  `self_attitude` tinyint(10) default NULL COMMENT '学习态度',
  `self_technique` tinyint(10) default NULL COMMENT '专业能力',
  `self_communication` tinyint(10) default NULL COMMENT '沟通能力',
  `self_cooperation` tinyint(10) NOT NULL COMMENT '协作能力',
  `self_achievement` tinyint(10) default NULL COMMENT '取得成绩',
  `self_organization` tinyint(10) default NULL COMMENT '如果角色是经理，则有组织能力这一项',
  `self_decision` tinyint(10) default NULL COMMENT '如果角色是经理，则有决策能力这一项',
  `self_score` float(10,0) default NULL COMMENT '自评得分',
  `self_mark` varchar(255) collate utf8_unicode_ci default NULL COMMENT '自我综合评价',
  `self_expectation` varchar(255) collate utf8_unicode_ci default NULL COMMENT '学习展望',
  `manager_attitude` tinyint(10) default '0' COMMENT '经理对组员评价中的——学习态度',
  `manager_technique` tinyint(10) default '0' COMMENT '经理对组员评价中的——专业能力',
  `manager_communication` tinyint(10) default '0' COMMENT '经理对组员评价中的——沟通能力',
  `manager_cooperation` tinyint(10) default '0' COMMENT '经理对组员评价中的——协作能力',
  `manager_docpasstime` tinyint(10) default '0' COMMENT '经理对组员评价中的——文档通过时间',
  `manager_docpassrate` tinyint(10) default '0' COMMENT '经理对组员评价中的——文档通过率',
  `manager_doccorrectness` tinyint(10) default '0' COMMENT '经理对组员评价中的——文档正确度',
  `manager_docinnovation` tinyint(10) default '0' COMMENT '经理对组员评价中的——文档创新情况',
  `manager_docstyle` tinyint(10) default '0' COMMENT '经理对组员评价中的——文档风格',
  `manager_score` float(10,0) default '0' COMMENT '经理对组员评价中的——总得分',
  `manager_mark` varchar(255) collate utf8_unicode_ci default '' COMMENT '经理对组员评价中的——总体评价',
  `instructor_attitude` tinyint(10) default NULL COMMENT '指导老师对个人评价中的学习态度',
  `instructor_updownquantity` tinyint(10) default NULL COMMENT '指导老师对个人评价中的上传下载数量',
  `instructor_updownquality` tinyint(10) default NULL COMMENT '指导老师对个人评价中的上传下载质量',
  `instructor_bbsquantity` tinyint(10) default NULL COMMENT '指导老师对个人评价中的bbs讨论次数',
  `instructor_bbsquality` tinyint(10) default NULL COMMENT '指导老师对个人评价中的bbs讨论质量',
  `instructor_score` float(10,0) default NULL COMMENT '指导老师对个人评价中的总体得分',
  `instructor_mark` varchar(255) collate utf8_unicode_ci default NULL COMMENT '指导老师对个人评价中的总体评价'
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci COMMENT='这个表用于存贮个人自评、经理对个人的评价和老师对个人的评价';
SET character_set_client = @saved_cs_client;

--
-- Dumping data for table `evaluation_member`
--

LOCK TABLES `evaluation_member` WRITE;
/*!40000 ALTER TABLE `evaluation_member` DISABLE KEYS */;
/*!40000 ALTER TABLE `evaluation_member` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `evaluation_mutual`
--

DROP TABLE IF EXISTS `evaluation_mutual`;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
CREATE TABLE `evaluation_mutual` (
  `instanceid` tinyint(10) default NULL,
  `taskid` tinyint(10) default NULL,
  `userid` tinyint(10) default NULL,
  `touserid` tinyint(10) default NULL,
  `roleid` tinyint(10) default NULL,
  `attitude` tinyint(10) default NULL,
  `technique` tinyint(10) default NULL,
  `communication` tinyint(10) default NULL,
  `cooperation` tinyint(10) default NULL,
  `organization` tinyint(10) default NULL,
  `decision` tinyint(10) default NULL,
  `helpme` tinyint(10) default NULL,
  `score` float(10,0) default NULL,
  `mark` varchar(255) collate utf8_unicode_ci default NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci COMMENT='此表存贮普通组员之间互评、组员对经理的评价信息。';
SET character_set_client = @saved_cs_client;

--
-- Dumping data for table `evaluation_mutual`
--

LOCK TABLES `evaluation_mutual` WRITE;
/*!40000 ALTER TABLE `evaluation_mutual` DISABLE KEYS */;
/*!40000 ALTER TABLE `evaluation_mutual` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `evaluation_team`
--

DROP TABLE IF EXISTS `evaluation_team`;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
CREATE TABLE `evaluation_team` (
  `instanceid` tinyint(10) default NULL,
  `taskid` tinyint(10) default NULL,
  `updownno` int(10) default '0' COMMENT '学员上传下载次数',
  `downno` int(10) default '0' COMMENT '上传的文档被下载次数',
  `bbsno` int(10) default '0' COMMENT 'BBS回帖大于10的主体数量',
  `updownquantity` tinyint(10) default NULL COMMENT '传上下载数量的得分',
  `updownquality` tinyint(10) default NULL COMMENT '上传下载质量的得分',
  `bbsquantity` tinyint(10) default NULL COMMENT 'bbs讨论次数的得分',
  `bbsquality` tinyint(10) default NULL COMMENT 'bbs讨论质量的得分',
  `docpasstime` tinyint(10) default NULL COMMENT '所有文档提交时间得分',
  `docinnovation` tinyint(10) default NULL COMMENT '创新情况得分',
  `doccorrectness` tinyint(10) default NULL COMMENT '正确情况得分',
  `docstyle` tinyint(10) default NULL COMMENT '文档风格得分',
  `score` float(10,0) default NULL COMMENT '总分',
  `mark` varchar(255) collate utf8_unicode_ci default NULL COMMENT '描述性评价'
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci COMMENT='此表存贮指导老师对项目小组的整体评价';
SET character_set_client = @saved_cs_client;

--
-- Dumping data for table `evaluation_team`
--

LOCK TABLES `evaluation_team` WRITE;
/*!40000 ALTER TABLE `evaluation_team` DISABLE KEYS */;
/*!40000 ALTER TABLE `evaluation_team` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `inputs`
--

DROP TABLE IF EXISTS `inputs`;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
CREATE TABLE `inputs` (
  `caseid` int(11) NOT NULL,
  `taskid` int(11) NOT NULL,
  `fileid` int(10) NOT NULL,
  `input` varchar(255) collate utf8_unicode_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci ROW_FORMAT=COMPACT;
SET character_set_client = @saved_cs_client;

--
-- Dumping data for table `inputs`
--

LOCK TABLES `inputs` WRITE;
/*!40000 ALTER TABLE `inputs` DISABLE KEYS */;
INSERT INTO `inputs` VALUES (11,2,0,'Project Description.doc'),(12,1,0,'P1.pdf'),(12,2,0,'P1.pdf'),(12,3,3,'Requirements.doc'),(13,1,0,'P2.pdf'),(13,2,0,'P2.pdf'),(13,3,3,'Requirements.doc'),(14,1,0,'P3.pdf'),(14,2,0,'P3.pdf'),(14,3,3,'Requirements.doc'),(15,1,0,'P1.doc'),(15,2,0,'P1.doc'),(15,3,3,'Requirements.doc'),(16,1,0,'P2.doc'),(16,2,0,'P2.doc'),(16,3,3,'Requirements.doc'),(17,1,0,'P3.doc'),(17,3,3,'Requirements.doc');
/*!40000 ALTER TABLE `inputs` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `ins_task_confirm`
--

DROP TABLE IF EXISTS `ins_task_confirm`;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
CREATE TABLE `ins_task_confirm` (
  `insId` int(10) NOT NULL,
  `taskId` int(10) NOT NULL,
  `roleId` int(10) NOT NULL,
  `isConfirmed` tinyint(1) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
SET character_set_client = @saved_cs_client;

--
-- Dumping data for table `ins_task_confirm`
--

LOCK TABLES `ins_task_confirm` WRITE;
/*!40000 ALTER TABLE `ins_task_confirm` DISABLE KEYS */;
/*!40000 ALTER TABLE `ins_task_confirm` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `instance_role`
--

DROP TABLE IF EXISTS `instance_role`;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
CREATE TABLE `instance_role` (
  `instanceid` int(10) unsigned NOT NULL,
  `roleid` int(10) unsigned NOT NULL,
  `actorid` int(10) NOT NULL default '-1' COMMENT 'the uid of the actor,99  means AI, 0 means instructor, 1 means PM',
  `status` tinyint(1) NOT NULL default '1' COMMENT ' open | closed',
  PRIMARY KEY  (`instanceid`,`roleid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci ROW_FORMAT=FIXED;
SET character_set_client = @saved_cs_client;

--
-- Dumping data for table `instance_role`
--

LOCK TABLES `instance_role` WRITE;
/*!40000 ALTER TABLE `instance_role` DISABLE KEYS */;
INSERT INTO `instance_role` VALUES (1,0,-1,1),(1,1,3,1),(1,2,-1,1),(1,3,-1,1),(1,4,-1,1),(1,5,-1,1),(1,6,-1,1),(2,0,-1,1),(2,1,-1,1),(2,2,-1,1),(2,3,-1,1),(2,4,-1,1),(2,5,-1,1),(2,6,-1,1);
/*!40000 ALTER TABLE `instance_role` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `instance_task`
--

DROP TABLE IF EXISTS `instance_task`;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
CREATE TABLE `instance_task` (
  `instanceid` int(10) unsigned NOT NULL,
  `taskid` int(10) unsigned NOT NULL,
  `status` int(10) NOT NULL,
  `starttime` datetime NOT NULL,
  `finishtime` datetime NOT NULL,
  `denies` int(11) NOT NULL,
  `reference` varchar(255) collate utf8_unicode_ci default NULL,
  `suggestions` varchar(255) collate utf8_unicode_ci default NULL,
  PRIMARY KEY  (`instanceid`,`taskid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci ROW_FORMAT=FIXED;
SET character_set_client = @saved_cs_client;

--
-- Dumping data for table `instance_task`
--

LOCK TABLES `instance_task` WRITE;
/*!40000 ALTER TABLE `instance_task` DISABLE KEYS */;
INSERT INTO `instance_task` VALUES (1,1,0,'0000-00-00 00:00:00','0000-00-00 00:00:00',0,NULL,NULL),(1,2,2,'0000-00-00 00:00:00','0000-00-00 00:00:00',0,NULL,NULL),(1,3,0,'0000-00-00 00:00:00','0000-00-00 00:00:00',0,NULL,NULL),(1,4,0,'0000-00-00 00:00:00','0000-00-00 00:00:00',0,NULL,NULL),(1,5,0,'0000-00-00 00:00:00','0000-00-00 00:00:00',0,NULL,NULL),(1,6,0,'0000-00-00 00:00:00','0000-00-00 00:00:00',0,NULL,NULL),(1,7,0,'0000-00-00 00:00:00','0000-00-00 00:00:00',0,NULL,NULL),(1,8,0,'0000-00-00 00:00:00','0000-00-00 00:00:00',0,NULL,NULL),(1,9,0,'0000-00-00 00:00:00','0000-00-00 00:00:00',0,NULL,NULL),(1,10,0,'0000-00-00 00:00:00','0000-00-00 00:00:00',0,NULL,NULL),(1,11,0,'0000-00-00 00:00:00','0000-00-00 00:00:00',0,NULL,NULL),(1,12,0,'0000-00-00 00:00:00','0000-00-00 00:00:00',0,NULL,NULL),(1,13,0,'0000-00-00 00:00:00','0000-00-00 00:00:00',0,NULL,NULL),(1,14,0,'0000-00-00 00:00:00','0000-00-00 00:00:00',0,NULL,NULL),(1,15,0,'0000-00-00 00:00:00','0000-00-00 00:00:00',0,NULL,NULL),(1,16,0,'0000-00-00 00:00:00','0000-00-00 00:00:00',0,NULL,NULL),(1,17,0,'0000-00-00 00:00:00','0000-00-00 00:00:00',0,NULL,NULL),(1,18,0,'0000-00-00 00:00:00','0000-00-00 00:00:00',0,NULL,NULL),(1,19,0,'0000-00-00 00:00:00','0000-00-00 00:00:00',0,NULL,NULL),(1,20,0,'0000-00-00 00:00:00','0000-00-00 00:00:00',0,NULL,NULL),(1,21,0,'0000-00-00 00:00:00','0000-00-00 00:00:00',0,NULL,NULL),(1,22,0,'0000-00-00 00:00:00','0000-00-00 00:00:00',0,NULL,NULL),(1,23,0,'0000-00-00 00:00:00','0000-00-00 00:00:00',0,NULL,NULL),(1,24,0,'0000-00-00 00:00:00','0000-00-00 00:00:00',0,NULL,NULL),(1,25,0,'0000-00-00 00:00:00','0000-00-00 00:00:00',0,NULL,NULL),(1,26,0,'0000-00-00 00:00:00','0000-00-00 00:00:00',0,NULL,NULL),(1,27,0,'0000-00-00 00:00:00','0000-00-00 00:00:00',0,NULL,NULL),(1,28,0,'0000-00-00 00:00:00','0000-00-00 00:00:00',0,NULL,NULL),(1,29,0,'0000-00-00 00:00:00','0000-00-00 00:00:00',0,NULL,NULL),(1,30,0,'0000-00-00 00:00:00','0000-00-00 00:00:00',0,NULL,NULL),(1,31,0,'0000-00-00 00:00:00','0000-00-00 00:00:00',0,NULL,NULL),(1,32,0,'0000-00-00 00:00:00','0000-00-00 00:00:00',0,NULL,NULL),(1,33,0,'0000-00-00 00:00:00','0000-00-00 00:00:00',0,NULL,NULL),(1,34,0,'0000-00-00 00:00:00','0000-00-00 00:00:00',0,NULL,NULL),(1,35,0,'0000-00-00 00:00:00','0000-00-00 00:00:00',0,NULL,NULL),(1,36,0,'0000-00-00 00:00:00','0000-00-00 00:00:00',0,NULL,NULL),(1,37,0,'0000-00-00 00:00:00','0000-00-00 00:00:00',0,NULL,NULL),(1,38,0,'0000-00-00 00:00:00','0000-00-00 00:00:00',0,NULL,NULL),(1,39,0,'0000-00-00 00:00:00','0000-00-00 00:00:00',0,NULL,NULL),(1,40,0,'0000-00-00 00:00:00','0000-00-00 00:00:00',0,NULL,NULL),(1,41,0,'0000-00-00 00:00:00','0000-00-00 00:00:00',0,NULL,NULL),(1,42,0,'0000-00-00 00:00:00','0000-00-00 00:00:00',0,NULL,NULL),(1,43,0,'0000-00-00 00:00:00','0000-00-00 00:00:00',0,NULL,NULL),(1,44,0,'0000-00-00 00:00:00','0000-00-00 00:00:00',0,NULL,NULL),(1,45,0,'0000-00-00 00:00:00','0000-00-00 00:00:00',0,NULL,NULL),(1,46,0,'0000-00-00 00:00:00','0000-00-00 00:00:00',0,NULL,NULL),(1,47,0,'0000-00-00 00:00:00','0000-00-00 00:00:00',0,NULL,NULL),(1,48,0,'0000-00-00 00:00:00','0000-00-00 00:00:00',0,NULL,NULL),(1,49,0,'0000-00-00 00:00:00','0000-00-00 00:00:00',0,NULL,NULL),(1,50,0,'0000-00-00 00:00:00','0000-00-00 00:00:00',0,NULL,NULL),(1,51,0,'0000-00-00 00:00:00','0000-00-00 00:00:00',0,NULL,NULL),(1,52,0,'0000-00-00 00:00:00','0000-00-00 00:00:00',0,NULL,NULL),(1,53,0,'0000-00-00 00:00:00','0000-00-00 00:00:00',0,NULL,NULL),(1,54,0,'0000-00-00 00:00:00','0000-00-00 00:00:00',0,NULL,NULL),(1,55,0,'0000-00-00 00:00:00','0000-00-00 00:00:00',0,NULL,NULL),(1,56,0,'0000-00-00 00:00:00','0000-00-00 00:00:00',0,NULL,NULL),(1,57,0,'0000-00-00 00:00:00','0000-00-00 00:00:00',0,NULL,NULL),(1,58,0,'0000-00-00 00:00:00','0000-00-00 00:00:00',0,NULL,NULL),(1,59,0,'0000-00-00 00:00:00','0000-00-00 00:00:00',0,NULL,NULL),(1,60,0,'0000-00-00 00:00:00','0000-00-00 00:00:00',0,NULL,NULL),(1,61,0,'0000-00-00 00:00:00','0000-00-00 00:00:00',0,NULL,NULL),(1,62,0,'0000-00-00 00:00:00','0000-00-00 00:00:00',0,NULL,NULL),(1,63,0,'0000-00-00 00:00:00','0000-00-00 00:00:00',0,NULL,NULL),(1,64,0,'0000-00-00 00:00:00','0000-00-00 00:00:00',0,NULL,NULL),(1,65,0,'0000-00-00 00:00:00','0000-00-00 00:00:00',0,NULL,NULL),(1,66,0,'0000-00-00 00:00:00','0000-00-00 00:00:00',0,NULL,NULL),(1,67,0,'0000-00-00 00:00:00','0000-00-00 00:00:00',0,NULL,NULL),(1,68,0,'0000-00-00 00:00:00','0000-00-00 00:00:00',0,NULL,NULL),(1,69,0,'0000-00-00 00:00:00','0000-00-00 00:00:00',0,NULL,NULL),(1,70,0,'0000-00-00 00:00:00','0000-00-00 00:00:00',0,NULL,NULL),(2,1,0,'0000-00-00 00:00:00','0000-00-00 00:00:00',0,NULL,NULL),(2,2,0,'0000-00-00 00:00:00','0000-00-00 00:00:00',0,NULL,NULL),(2,3,0,'0000-00-00 00:00:00','0000-00-00 00:00:00',0,NULL,NULL),(2,4,0,'0000-00-00 00:00:00','0000-00-00 00:00:00',0,NULL,NULL),(2,5,0,'0000-00-00 00:00:00','0000-00-00 00:00:00',0,NULL,NULL),(2,6,0,'0000-00-00 00:00:00','0000-00-00 00:00:00',0,NULL,NULL),(2,7,0,'0000-00-00 00:00:00','0000-00-00 00:00:00',0,NULL,NULL),(2,8,0,'0000-00-00 00:00:00','0000-00-00 00:00:00',0,NULL,NULL),(2,9,0,'0000-00-00 00:00:00','0000-00-00 00:00:00',0,NULL,NULL),(2,10,0,'0000-00-00 00:00:00','0000-00-00 00:00:00',0,NULL,NULL),(2,11,0,'0000-00-00 00:00:00','0000-00-00 00:00:00',0,NULL,NULL),(2,12,0,'0000-00-00 00:00:00','0000-00-00 00:00:00',0,NULL,NULL),(2,13,0,'0000-00-00 00:00:00','0000-00-00 00:00:00',0,NULL,NULL),(2,14,0,'0000-00-00 00:00:00','0000-00-00 00:00:00',0,NULL,NULL),(2,15,0,'0000-00-00 00:00:00','0000-00-00 00:00:00',0,NULL,NULL),(2,16,0,'0000-00-00 00:00:00','0000-00-00 00:00:00',0,NULL,NULL),(2,17,0,'0000-00-00 00:00:00','0000-00-00 00:00:00',0,NULL,NULL),(2,18,0,'0000-00-00 00:00:00','0000-00-00 00:00:00',0,NULL,NULL),(2,19,0,'0000-00-00 00:00:00','0000-00-00 00:00:00',0,NULL,NULL),(2,20,0,'0000-00-00 00:00:00','0000-00-00 00:00:00',0,NULL,NULL),(2,21,0,'0000-00-00 00:00:00','0000-00-00 00:00:00',0,NULL,NULL),(2,22,0,'0000-00-00 00:00:00','0000-00-00 00:00:00',0,NULL,NULL),(2,23,0,'0000-00-00 00:00:00','0000-00-00 00:00:00',0,NULL,NULL),(2,24,0,'0000-00-00 00:00:00','0000-00-00 00:00:00',0,NULL,NULL),(2,25,0,'0000-00-00 00:00:00','0000-00-00 00:00:00',0,NULL,NULL),(2,26,0,'0000-00-00 00:00:00','0000-00-00 00:00:00',0,NULL,NULL),(2,27,0,'0000-00-00 00:00:00','0000-00-00 00:00:00',0,NULL,NULL),(2,28,0,'0000-00-00 00:00:00','0000-00-00 00:00:00',0,NULL,NULL),(2,29,0,'0000-00-00 00:00:00','0000-00-00 00:00:00',0,NULL,NULL),(2,30,0,'0000-00-00 00:00:00','0000-00-00 00:00:00',0,NULL,NULL),(2,31,0,'0000-00-00 00:00:00','0000-00-00 00:00:00',0,NULL,NULL),(2,32,0,'0000-00-00 00:00:00','0000-00-00 00:00:00',0,NULL,NULL),(2,33,0,'0000-00-00 00:00:00','0000-00-00 00:00:00',0,NULL,NULL),(2,34,0,'0000-00-00 00:00:00','0000-00-00 00:00:00',0,NULL,NULL),(2,35,0,'0000-00-00 00:00:00','0000-00-00 00:00:00',0,NULL,NULL),(2,36,0,'0000-00-00 00:00:00','0000-00-00 00:00:00',0,NULL,NULL),(2,37,0,'0000-00-00 00:00:00','0000-00-00 00:00:00',0,NULL,NULL),(2,38,0,'0000-00-00 00:00:00','0000-00-00 00:00:00',0,NULL,NULL),(2,39,0,'0000-00-00 00:00:00','0000-00-00 00:00:00',0,NULL,NULL),(2,40,0,'0000-00-00 00:00:00','0000-00-00 00:00:00',0,NULL,NULL),(2,41,0,'0000-00-00 00:00:00','0000-00-00 00:00:00',0,NULL,NULL),(2,42,0,'0000-00-00 00:00:00','0000-00-00 00:00:00',0,NULL,NULL),(2,43,0,'0000-00-00 00:00:00','0000-00-00 00:00:00',0,NULL,NULL),(2,44,0,'0000-00-00 00:00:00','0000-00-00 00:00:00',0,NULL,NULL),(2,45,0,'0000-00-00 00:00:00','0000-00-00 00:00:00',0,NULL,NULL),(2,46,0,'0000-00-00 00:00:00','0000-00-00 00:00:00',0,NULL,NULL),(2,47,0,'0000-00-00 00:00:00','0000-00-00 00:00:00',0,NULL,NULL),(2,48,0,'0000-00-00 00:00:00','0000-00-00 00:00:00',0,NULL,NULL),(2,49,0,'0000-00-00 00:00:00','0000-00-00 00:00:00',0,NULL,NULL),(2,50,0,'0000-00-00 00:00:00','0000-00-00 00:00:00',0,NULL,NULL),(2,51,0,'0000-00-00 00:00:00','0000-00-00 00:00:00',0,NULL,NULL),(2,52,0,'0000-00-00 00:00:00','0000-00-00 00:00:00',0,NULL,NULL),(2,53,0,'0000-00-00 00:00:00','0000-00-00 00:00:00',0,NULL,NULL),(2,54,0,'0000-00-00 00:00:00','0000-00-00 00:00:00',0,NULL,NULL),(2,55,0,'0000-00-00 00:00:00','0000-00-00 00:00:00',0,NULL,NULL),(2,56,0,'0000-00-00 00:00:00','0000-00-00 00:00:00',0,NULL,NULL),(2,57,0,'0000-00-00 00:00:00','0000-00-00 00:00:00',0,NULL,NULL),(2,58,0,'0000-00-00 00:00:00','0000-00-00 00:00:00',0,NULL,NULL),(2,59,0,'0000-00-00 00:00:00','0000-00-00 00:00:00',0,NULL,NULL),(2,60,0,'0000-00-00 00:00:00','0000-00-00 00:00:00',0,NULL,NULL),(2,61,0,'0000-00-00 00:00:00','0000-00-00 00:00:00',0,NULL,NULL),(2,62,0,'0000-00-00 00:00:00','0000-00-00 00:00:00',0,NULL,NULL),(2,63,0,'0000-00-00 00:00:00','0000-00-00 00:00:00',0,NULL,NULL),(2,64,0,'0000-00-00 00:00:00','0000-00-00 00:00:00',0,NULL,NULL),(2,65,0,'0000-00-00 00:00:00','0000-00-00 00:00:00',0,NULL,NULL),(2,66,0,'0000-00-00 00:00:00','0000-00-00 00:00:00',0,NULL,NULL),(2,67,0,'0000-00-00 00:00:00','0000-00-00 00:00:00',0,NULL,NULL),(2,68,0,'0000-00-00 00:00:00','0000-00-00 00:00:00',0,NULL,NULL),(2,69,0,'0000-00-00 00:00:00','0000-00-00 00:00:00',0,NULL,NULL),(2,70,0,'0000-00-00 00:00:00','0000-00-00 00:00:00',0,NULL,NULL);
/*!40000 ALTER TABLE `instance_task` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `instances`
--

DROP TABLE IF EXISTS `instances`;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
CREATE TABLE `instances` (
  `uid` int(10) unsigned NOT NULL auto_increment,
  `caseid` int(10) unsigned NOT NULL,
  `instancename` varchar(255) collate utf8_unicode_ci NOT NULL,
  `creatorid` int(10) unsigned NOT NULL,
  `status` int(10) NOT NULL,
  `creationtime` datetime NOT NULL,
  `starttime` datetime NOT NULL,
  `tasksfinishtime` datetime default NULL,
  `finishtime` datetime NOT NULL,
  `progress` tinyint(4) default '0',
  `evaluationtype` tinyint(10) NOT NULL,
  `evaluationstatus` tinyint(4) NOT NULL default '0',
  `lastevataskid` tinyint(4) NOT NULL default '-1',
  PRIMARY KEY  (`uid`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci ROW_FORMAT=DYNAMIC;
SET character_set_client = @saved_cs_client;

--
-- Dumping data for table `instances`
--

LOCK TABLES `instances` WRITE;
/*!40000 ALTER TABLE `instances` DISABLE KEYS */;
INSERT INTO `instances` VALUES (1,11,'pbcls_test_7_5',3,3,'2010-07-05 10:54:48','2010-07-05 10:55:04',NULL,'0000-00-00 00:00:00',0,1,0,-1),(2,11,'new111111111111',3,0,'2010-08-10 23:36:32','0000-00-00 00:00:00',NULL,'0000-00-00 00:00:00',0,0,0,-1);
/*!40000 ALTER TABLE `instances` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `messages`
--

DROP TABLE IF EXISTS `messages`;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
CREATE TABLE `messages` (
  `uid` int(10) NOT NULL auto_increment,
  `title` varchar(100) collate utf8_unicode_ci NOT NULL,
  `from` int(10) unsigned NOT NULL,
  `to` int(10) unsigned NOT NULL,
  `body` text collate utf8_unicode_ci NOT NULL,
  `sendtime` timestamp NOT NULL default CURRENT_TIMESTAMP on update CURRENT_TIMESTAMP,
  `isreaded` tinyint(1) NOT NULL default '0',
  PRIMARY KEY  (`uid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci ROW_FORMAT=DYNAMIC;
SET character_set_client = @saved_cs_client;

--
-- Dumping data for table `messages`
--

LOCK TABLES `messages` WRITE;
/*!40000 ALTER TABLE `messages` DISABLE KEYS */;
/*!40000 ALTER TABLE `messages` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `news_table`
--

DROP TABLE IF EXISTS `news_table`;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
CREATE TABLE `news_table` (
  `insId` int(10) NOT NULL,
  `taskId` int(10) NOT NULL,
  `time` int(32) unsigned NOT NULL,
  `recRoleId` int(10) NOT NULL,
  `newsContent` varchar(255) collate utf8_unicode_ci NOT NULL,
  `docId` int(10) NOT NULL default '-1'
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
SET character_set_client = @saved_cs_client;

--
-- Dumping data for table `news_table`
--

LOCK TABLES `news_table` WRITE;
/*!40000 ALTER TABLE `news_table` DISABLE KEYS */;
INSERT INTO `news_table` VALUES (1,-1,1278298504,-1,'项目创建者开始了工程！',-1),(1,2,1278298504,-1,'任务准备就绪，等待项目经理开始任务！',-1),(1,2,1278298504,1,'任务准备就绪，等待您开始任务！',-1);
/*!40000 ALTER TABLE `news_table` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `newsubmits`
--

DROP TABLE IF EXISTS `newsubmits`;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
CREATE TABLE `newsubmits` (
  `uid` int(11) NOT NULL auto_increment,
  `instanceid` int(11) NOT NULL,
  `taskid` int(11) NOT NULL,
  `standardfileid` int(10) NOT NULL,
  `status` int(10) NOT NULL,
  `path` varchar(255) collate utf8_unicode_ci NOT NULL,
  `file` varchar(255) collate utf8_unicode_ci NOT NULL,
  `denyReason` varchar(255) collate utf8_unicode_ci default NULL,
  `denySuggestions` varchar(255) collate utf8_unicode_ci default NULL,
  `submittime` datetime NOT NULL,
  `accepttime` datetime NOT NULL,
  `uploader` int(11) NOT NULL,
  `uploaderCurRole` int(10) NOT NULL,
  PRIMARY KEY  (`uid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci ROW_FORMAT=COMPACT;
SET character_set_client = @saved_cs_client;

--
-- Dumping data for table `newsubmits`
--

LOCK TABLES `newsubmits` WRITE;
/*!40000 ALTER TABLE `newsubmits` DISABLE KEYS */;
/*!40000 ALTER TABLE `newsubmits` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `outputs`
--

DROP TABLE IF EXISTS `outputs`;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
CREATE TABLE `outputs` (
  `caseid` int(11) NOT NULL,
  `taskid` int(11) NOT NULL,
  `fileid` int(10) NOT NULL,
  `output` varchar(255) collate utf8_unicode_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci ROW_FORMAT=COMPACT;
SET character_set_client = @saved_cs_client;

--
-- Dumping data for table `outputs`
--

LOCK TABLES `outputs` WRITE;
/*!40000 ALTER TABLE `outputs` DISABLE KEYS */;
INSERT INTO `outputs` VALUES (11,2,1,'Project View and Scope.pdf'),(11,3,2,'STD Reference.pdf'),(11,4,2,'STD Reference.pdf'),(11,5,2,'STD Reference.pdf'),(11,6,3,'Feasibility Report.pdf'),(11,7,4,'Milestone Report.pdf'),(11,8,2,'STD Reference.pdf'),(11,9,2,'STD Reference.pdf'),(11,10,2,'STD Reference.pdf'),(11,11,2,'STD Reference.pdf'),(11,12,5,'Project Chart.pdf'),(11,13,2,'STD Reference.pdf'),(11,14,2,'STD Reference.pdf'),(11,15,2,'STD Reference.pdf'),(11,16,6,'WBS.mpp'),(11,17,2,'STD Reference.pdf'),(11,18,7,'Overall Plan.pdf'),(11,19,2,'STD Reference.pdf'),(11,20,2,'STD Reference.pdf'),(11,21,2,'STD Reference.pdf'),(11,22,8,'QA Plan.pdf'),(11,23,4,'Milestone Report.pdf'),(11,24,2,'STD Reference.pdf'),(11,25,2,'STD Reference.pdf'),(11,26,2,'STD Reference.pdf'),(11,27,2,'STD Reference.pdf'),(11,28,2,'STD Reference.pdf'),(11,29,9,'Requirement Engineering Plan.pdf'),(11,30,2,'STD Reference.pdf'),(11,31,4,'Milestone Report.pdf'),(11,32,2,'STD Reference.pdf'),(11,33,2,'STD Reference.pdf'),(11,34,2,'STD Reference.pdf'),(11,35,2,'STD Reference.pdf'),(11,36,2,'STD Reference.pdf'),(11,37,2,'STD Reference.pdf'),(11,38,10,'SRS.pdf'),(11,39,2,'STD Reference.pdf'),(11,40,4,'Milestone Report.pdf'),(11,41,2,'STD Reference.pdf'),(11,42,2,'STD Reference.pdf'),(11,43,2,'STD Reference.pdf'),(11,44,2,'STD Reference.pdf'),(11,45,11,'Requirement Change Report.pdf'),(11,46,2,'STD Reference.pdf'),(11,47,4,'Milestone Report.pdf'),(11,48,2,'STD Reference.pdf'),(11,49,2,'STD Reference.pdf'),(11,50,2,'STD Reference.pdf'),(11,51,2,'STD Reference.pdf'),(11,52,12,'System Design and Implement Plan.pdf'),(11,53,13,'Preliminary Design.pdf'),(11,54,2,'STD Reference.pdf'),(11,55,2,'STD Reference.pdf'),(11,56,2,'STD Reference.pdf'),(11,57,2,'STD Reference.pdf'),(11,58,2,'STD Reference.pdf'),(11,59,4,'Milestone Report.pdf'),(11,60,2,'STD Reference.pdf'),(11,61,14,'Test Plan.pdf'),(11,62,15,'Deployment Plan.pdf'),(11,63,16,'Traning Plan.pdf'),(11,64,17,'System Maintenance Plan.pdf'),(11,65,4,'Milestone Report.pdf'),(11,66,2,'STD Reference.pdf'),(11,67,2,'STD Reference.pdf'),(11,68,2,'STD Reference.pdf'),(11,69,18,'Final Report.pdf'),(11,70,4,'Milestone Report.pdf'),(12,1,1,'solution.cpp'),(12,2,2,'testcases.txt'),(12,3,4,'report.pdf'),(13,1,1,'solution.cpp'),(13,2,2,'testcases.txt'),(13,3,4,'report.pdf'),(14,1,1,'solution.cpp'),(14,2,2,'testcases.txt'),(14,3,4,'report.pdf'),(15,1,1,'Source.zip'),(15,2,2,'Test.zip'),(15,3,4,'Report.doc'),(15,4,5,'Project.ppt'),(16,1,1,'Source.zip'),(16,2,2,'Test.zip'),(16,3,4,'Report.doc'),(16,4,5,'Project.ppt'),(17,1,1,'introduction.doc'),(17,2,2,'anlysis.doc'),(17,3,4,'Report.doc'),(17,4,5,'Project.ppt');
/*!40000 ALTER TABLE `outputs` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `ref_contribute`
--

DROP TABLE IF EXISTS `ref_contribute`;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
CREATE TABLE `ref_contribute` (
  `fileId` int(10) NOT NULL auto_increment,
  `fileName` varchar(255) collate utf8_unicode_ci NOT NULL,
  `refName` varchar(255) collate utf8_unicode_ci NOT NULL,
  `uploaderId` int(10) NOT NULL,
  `uploadTime` datetime NOT NULL,
  `path` varchar(255) collate utf8_unicode_ci NOT NULL,
  `caseId` int(10) NOT NULL,
  `description` text collate utf8_unicode_ci NOT NULL,
  `downloadedTimes` int(10) NOT NULL,
  PRIMARY KEY  (`fileId`),
  UNIQUE KEY `fileId` (`fileId`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
SET character_set_client = @saved_cs_client;

--
-- Dumping data for table `ref_contribute`
--

LOCK TABLES `ref_contribute` WRITE;
/*!40000 ALTER TABLE `ref_contribute` DISABLE KEYS */;
/*!40000 ALTER TABLE `ref_contribute` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `ref_download`
--

DROP TABLE IF EXISTS `ref_download`;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
CREATE TABLE `ref_download` (
  `fileId` int(10) NOT NULL,
  `downloadTime` datetime NOT NULL,
  `downloadUserId` int(10) NOT NULL,
  UNIQUE KEY `fileId` (`fileId`),
  CONSTRAINT `ref_download_ibfk_1` FOREIGN KEY (`fileId`) REFERENCES `ref_contribute` (`fileId`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
SET character_set_client = @saved_cs_client;

--
-- Dumping data for table `ref_download`
--

LOCK TABLES `ref_download` WRITE;
/*!40000 ALTER TABLE `ref_download` DISABLE KEYS */;
/*!40000 ALTER TABLE `ref_download` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `relations`
--

DROP TABLE IF EXISTS `relations`;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
CREATE TABLE `relations` (
  `caseid` int(11) NOT NULL,
  `childid` int(11) NOT NULL,
  `parentid` int(11) NOT NULL,
  PRIMARY KEY  (`caseid`,`childid`,`parentid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci ROW_FORMAT=COMPACT;
SET character_set_client = @saved_cs_client;

--
-- Dumping data for table `relations`
--

LOCK TABLES `relations` WRITE;
/*!40000 ALTER TABLE `relations` DISABLE KEYS */;
INSERT INTO `relations` VALUES (11,2,1),(11,3,1),(11,4,1),(11,5,1),(11,6,1),(11,9,8),(11,10,9),(11,11,9),(11,12,9),(11,13,8),(11,14,13),(11,15,13),(11,16,13),(11,17,13),(11,18,13),(11,19,8),(11,20,19),(11,21,19),(11,22,19),(11,25,24),(11,26,24),(11,27,24),(11,28,24),(11,29,24),(11,30,24),(11,33,32),(11,34,32),(11,35,32),(11,36,32),(11,37,32),(11,38,32),(11,39,32),(11,42,41),(11,43,41),(11,44,41),(11,45,41),(11,46,41),(11,49,48),(11,50,49),(11,51,49),(11,52,49),(11,53,49),(11,54,48),(11,55,54),(11,56,54),(11,57,54),(11,58,54),(11,61,60),(11,62,60),(11,63,60),(11,64,60),(11,67,66),(11,68,66),(11,69,66);
/*!40000 ALTER TABLE `relations` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `resources`
--

DROP TABLE IF EXISTS `resources`;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
CREATE TABLE `resources` (
  `caseid` int(11) NOT NULL,
  `taskid` int(11) NOT NULL,
  `resourceid` int(11) NOT NULL,
  PRIMARY KEY  (`caseid`,`taskid`,`resourceid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci ROW_FORMAT=COMPACT;
SET character_set_client = @saved_cs_client;

--
-- Dumping data for table `resources`
--

LOCK TABLES `resources` WRITE;
/*!40000 ALTER TABLE `resources` DISABLE KEYS */;
INSERT INTO `resources` VALUES (11,1,1),(11,1,2),(11,1,3),(11,1,4),(11,2,1),(11,3,2),(11,4,3),(11,5,4),(11,6,1),(11,7,1),(11,8,1),(11,8,2),(11,8,3),(11,8,4),(11,8,5),(11,8,6),(11,9,1),(11,9,2),(11,10,1),(11,11,1),(11,12,2),(11,13,1),(11,13,2),(11,13,3),(11,13,4),(11,14,3),(11,15,4),(11,16,2),(11,17,3),(11,18,1),(11,19,5),(11,19,6),(11,20,5),(11,21,6),(11,22,5),(11,23,1),(11,24,1),(11,24,2),(11,24,3),(11,24,4),(11,25,2),(11,26,3),(11,27,4),(11,28,2),(11,29,3),(11,30,1),(11,31,1),(11,32,1),(11,32,2),(11,32,3),(11,32,4),(11,33,1),(11,34,4),(11,35,2),(11,36,3),(11,37,4),(11,38,1),(11,39,1),(11,40,1),(11,41,1),(11,41,2),(11,41,3),(11,41,4),(11,42,1),(11,43,4),(11,44,2),(11,45,3),(11,46,1),(11,47,1),(11,48,1),(11,48,2),(11,48,3),(11,48,4),(11,48,5),(11,48,6),(11,49,2),(11,49,3),(11,49,4),(11,50,3),(11,51,4),(11,52,4),(11,53,2),(11,54,1),(11,54,5),(11,54,6),(11,55,1),(11,56,1),(11,57,5),(11,57,6),(11,58,5),(11,58,6),(11,59,1),(11,60,2),(11,60,3),(11,60,5),(11,60,6),(11,61,5),(11,62,6),(11,63,2),(11,64,3),(11,65,1),(11,66,1),(11,67,1),(11,68,1),(11,69,1),(11,70,1),(12,1,1),(12,2,2),(12,3,3),(13,1,1),(13,2,2),(13,3,3),(14,1,1),(14,2,2),(14,3,3),(15,1,1),(15,2,2),(15,3,3),(15,4,3),(16,1,1),(16,2,2),(16,3,3),(16,4,3),(17,1,1),(17,2,2),(17,3,3),(17,4,3);
/*!40000 ALTER TABLE `resources` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `roles`
--

DROP TABLE IF EXISTS `roles`;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
CREATE TABLE `roles` (
  `caseid` int(11) NOT NULL,
  `roleid` int(11) NOT NULL,
  `role` varchar(255) collate utf8_unicode_ci NOT NULL,
  `rolename` varchar(255) collate utf8_unicode_ci NOT NULL,
  `description` text collate utf8_unicode_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci ROW_FORMAT=DYNAMIC;
SET character_set_client = @saved_cs_client;

--
-- Dumping data for table `roles`
--

LOCK TABLES `roles` WRITE;
/*!40000 ALTER TABLE `roles` DISABLE KEYS */;
INSERT INTO `roles` VALUES (11,0,'instructor','指导者',''),(11,1,'PM','Player1','项目经理'),(11,2,'DEVELOPER','Player2',''),(11,3,'DEVELOPER','Player3',''),(11,4,'DEVELOPER','Player4',''),(11,5,'TESTER','Player5',''),(11,6,'TESTER','Player6',''),(12,0,'instructor','指导者',''),(12,1,'PM','Programmer',''),(12,2,'Member','Tester',''),(12,3,'Member','Writer',''),(13,0,'instructor','指导者',''),(13,1,'PM','Programmer',''),(13,2,'Member','Tester',''),(13,3,'Member','Writer',''),(14,0,'instructor','指导者',''),(14,1,'PM','Programmer',''),(14,2,'Member','Tester',''),(14,3,'Member','Writer',''),(15,0,'instructor','指导者',''),(15,1,'PM','Programmer',''),(15,2,'Member','Tester',''),(15,3,'Member','Writer',''),(16,0,'instructor','指导者',''),(16,1,'PM','Programmer',''),(16,2,'Member','Tester',''),(16,3,'Member','Writer',''),(17,0,'instructor','指导者',''),(17,1,'PM','Player1',''),(17,2,'Member','Player2',''),(17,3,'Member','Player3','');
/*!40000 ALTER TABLE `roles` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `sessions`
--

DROP TABLE IF EXISTS `sessions`;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
CREATE TABLE `sessions` (
  `session_id` varchar(32) character set latin1 NOT NULL,
  `session_last_access` int(10) unsigned default NULL,
  `session_data` text character set latin1,
  PRIMARY KEY  (`session_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
SET character_set_client = @saved_cs_client;

--
-- Dumping data for table `sessions`
--

LOCK TABLES `sessions` WRITE;
/*!40000 ALTER TABLE `sessions` DISABLE KEYS */;
INSERT INTO `sessions` VALUES ('17020386725a8d57776ab6fc0367c8f1',1278298939,'sess_last_access|i:1278298939;sess_ip_address|s:13:\"10.214.29.111\";sess_useragent|s:50:\"Mozilla/5.0 (X11; U; Linux i686; zh-CN; rv:1.9.2.6\";sess_last_regenerated|i:1278298935;user_name|s:4:\"user\";user_gid|s:1:\"2\";user_id|s:1:\"3\";score|s:3:\"666\";onlinetime|s:18:\"18å°æ—¶37åˆ†29ç§’\";grade|i:3;logintime|i:1278298939;'),('1a3d869e29cdc6e0db3c20411857c59e',1278298765,'sess_last_access|i:1278298765;sess_ip_address|s:13:\"10.214.29.112\";sess_useragent|s:50:\"Mozilla/5.0 (Windows; U; Windows NT 6.1; en-US) Ap\";sess_last_regenerated|i:1278298765;'),('26ca4db08aee5ed1e4684459246566e7',1281454855,'sess_last_access|i:1281454855;sess_ip_address|s:13:\"10.15.173.174\";sess_useragent|s:50:\"Mozilla/4.0 (compatible; MSIE 8.0; Windows NT 6.1;\";sess_last_regenerated|i:1281454855;'),('472c9c3fbfb5a8b85bce2fecf09d8a24',1281455095,'sess_last_access|i:1281455095;sess_ip_address|s:13:\"10.15.173.174\";sess_useragent|s:50:\"Mozilla/4.0 (compatible; MSIE 6.0; Windows NT 5.1;\";sess_last_regenerated|i:1281455066;'),('6f698f8d3e8cf2acf497b9bfecba5cae',1281241591,'sess_last_access|i:1281241591;sess_ip_address|s:10:\"10.10.2.57\";sess_useragent|s:50:\"Mozilla/4.0 (compatible; MSIE 6.0; Windows NT 5.1;\";sess_last_regenerated|i:1281241591;'),('7a149981a84219dfef25b596ee4298fe',1279516583,'sess_last_access|i:1279516583;sess_ip_address|s:13:\"10.15.173.174\";sess_useragent|s:50:\"Mozilla/4.0 (compatible; MSIE 8.0; Windows NT 6.1;\";sess_last_regenerated|i:1279516583;'),('92932eaa0764ca5e3e57195cd8beb4bd',1281455184,'sess_last_access|i:1281455184;sess_ip_address|s:13:\"10.15.173.174\";sess_useragent|s:50:\"Mozilla/4.0 (compatible; MSIE 8.0; Windows NT 6.1;\";sess_last_regenerated|i:1281455069;user_name|s:5:\"admin\";user_gid|s:1:\"0\";'),('c2e1d733a86b69608999358f31c655f4',1278312279,'sess_last_access|i:1278312279;sess_ip_address|s:12:\"10.214.29.12\";sess_useragent|s:50:\"Mozilla/4.0 (compatible; MSIE 7.0; Windows NT 6.1;\";sess_last_regenerated|i:1278312279;'),('c45c95936ebb6d984c3b2a3595e69ab9',1281149291,'sess_last_access|i:1281149291;sess_ip_address|s:13:\"10.15.173.174\";sess_useragent|s:50:\"Mozilla/4.0 (compatible; MSIE 8.0; Windows NT 6.1;\";sess_last_regenerated|i:1281149155;user_name|s:4:\"user\";user_gid|s:1:\"2\";user_id|s:1:\"3\";score|s:3:\"666\";onlinetime|s:18:\"18å°æ—¶38åˆ†16ç§’\";grade|i:3;logintime|i:1281149215;'),('e2cb25cfce40606a7572335dd48506fa',1281455069,'sess_last_access|i:1281455069;sess_ip_address|s:13:\"10.15.173.174\";sess_useragent|s:50:\"Mozilla/4.0 (compatible; MSIE 8.0; Windows NT 6.1;\";sess_last_regenerated|i:1281455069;'),('fe8c96f7c05cb203128b0f6db978f39e',1278299299,'sess_last_access|i:1278299299;sess_ip_address|s:13:\"10.214.29.112\";sess_useragent|s:50:\"Mozilla/5.0 (Windows; U; Windows NT 6.1; en-US) Ap\";sess_last_regenerated|i:1278299299;user_name|s:4:\"user\";user_gid|s:1:\"2\";user_id|s:1:\"3\";score|s:3:\"666\";onlinetime|s:18:\"18å°æ—¶37åˆ†29ç§’\";grade|i:3;logintime|i:1278298466;ins_id|s:1:\"1\";');
/*!40000 ALTER TABLE `sessions` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tasks`
--

DROP TABLE IF EXISTS `tasks`;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
CREATE TABLE `tasks` (
  `caseid` int(10) unsigned NOT NULL,
  `taskid` int(10) NOT NULL,
  `taskname` varchar(255) collate utf8_unicode_ci NOT NULL,
  `description` text collate utf8_unicode_ci NOT NULL,
  `isparent` tinyint(1) NOT NULL,
  `ismilestone` tinyint(1) NOT NULL,
  `iscritical` tinyint(1) NOT NULL,
  `duration` int(10) unsigned NOT NULL,
  `earlystart` int(10) NOT NULL,
  `earlyfinish` int(10) NOT NULL,
  `latestart` int(10) NOT NULL,
  `latefinish` int(10) NOT NULL,
  `WBS` varchar(255) collate utf8_unicode_ci NOT NULL,
  PRIMARY KEY  (`caseid`,`taskid`),
  KEY `caseid` (`caseid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci ROW_FORMAT=DYNAMIC;
SET character_set_client = @saved_cs_client;

--
-- Dumping data for table `tasks`
--

LOCK TABLES `tasks` WRITE;
/*!40000 ALTER TABLE `tasks` DISABLE KEYS */;
INSERT INTO `tasks` VALUES (11,1,'可行性分析','',1,0,1,109,0,109,0,109,'1'),(11,2,'明确项目目标','',0,0,1,2,0,2,0,2,'1.1'),(11,3,'分析现有系统','',0,0,1,2,2,4,2,4,'1.2'),(11,4,'分析建议技术','',0,0,1,2,2,4,2,4,'1.3'),(11,5,'分析经济可行性','',0,0,1,2,4,6,4,6,'1.4'),(11,6,'编写《项目可行性报告》','',0,0,1,2,6,8,6,8,'1.5'),(11,7,'可行性分析完成','',0,1,1,1,8,9,8,9,'2'),(11,8,'总体项目计划','',1,0,1,10,9,19,9,19,'3'),(11,9,'制定项目章程','',1,0,1,4,9,13,9,13,'3.1'),(11,10,'填写项目章程表格','',0,0,1,1,9,10,9,10,'3.1.1'),(11,11,'项目干系人许可','',0,0,1,1,10,11,10,11,'3.1.2'),(11,12,'编制《项目章程》','',0,0,1,2,11,13,11,13,'3.1.3'),(11,13,'制定项目总体计划','',1,0,1,6,13,19,13,19,'3.2'),(11,14,'定义工作内容','',0,0,1,1,13,14,13,14,'3.2.1'),(11,15,'明确验收标准','',0,0,1,1,14,15,14,15,'3.2.2'),(11,16,'任务分解','',0,0,1,2,14,16,14,16,'3.2.3'),(11,17,'划分组织和责任','',0,0,1,1,16,17,16,17,'3.2.4'),(11,18,'编制《项目总体计划》','',0,0,1,2,17,19,17,19,'3.2.5'),(11,19,'制定QA计划','',1,0,1,4,9,13,9,13,'3.3'),(11,20,'项目风险分析','',0,0,1,1,9,10,9,10,'3.3.1'),(11,21,'明确质量规范','',0,0,1,1,10,11,10,11,'3.3.2'),(11,22,'编制《QA计划》','',0,0,1,2,11,13,11,13,'3.3.3'),(11,23,'总体项目计划完成','',0,1,1,1,19,20,19,20,'4'),(11,24,'需求计划','',1,0,1,12,20,32,20,32,'5'),(11,25,'需求进度计划','',0,0,1,2,20,22,20,22,'5.1'),(11,26,'费用成本估计','',0,0,1,2,22,24,22,24,'5.2'),(11,27,'人力资源分配','',0,0,1,2,24,26,24,26,'5.3'),(11,28,'变更管理计划','',0,0,1,2,26,28,26,28,'5.4'),(11,29,'制定《需求工程计划》','',0,0,1,3,28,31,28,31,'5.5'),(11,30,'计划评审','',0,0,1,1,31,32,31,32,'5.6'),(11,31,'需求计划完成','',0,1,1,1,32,33,32,33,'6'),(11,32,'需求分析','',1,0,1,17,33,50,33,50,'7'),(11,33,'客户会议','',0,0,1,5,33,38,33,38,'7.1'),(11,34,'绘制关联图','',0,0,1,2,38,40,38,40,'7.2'),(11,35,'确定需求优先级','',0,0,1,2,38,40,38,40,'7.3'),(11,36,'建立需求模型','',0,0,1,3,40,43,40,43,'7.4'),(11,37,'编写数据字典','',0,0,1,3,43,46,43,46,'7.5'),(11,38,'编制《软件需求规格说明书》','',0,0,1,3,46,49,46,49,'7.6'),(11,39,'需求评审','',0,0,1,1,49,50,49,50,'7.7'),(11,40,'需求分析完成','',0,1,1,1,50,51,50,51,'8'),(11,41,'需求变更','',1,0,1,5,51,56,51,56,'9'),(11,42,'建立变更控制委员会','',0,0,1,1,51,52,51,52,'9.1'),(11,43,'进行变更影响分析','',0,0,1,1,52,53,52,53,'9.2'),(11,44,'确定变更控制过程','',0,0,1,1,53,54,53,54,'9.3'),(11,45,'编制《软件需求变更文档》','',0,0,1,1,54,55,54,55,'9.4'),(11,46,'需求变更评审','',0,0,1,1,55,56,55,56,'9.5'),(11,47,'需求变更完成','',0,1,1,1,56,57,56,57,'10'),(11,48,'系统设计与实现','',1,0,1,33,57,90,57,90,'11'),(11,49,'系统设计','',1,0,1,16,57,73,57,73,'11.1'),(11,50,'系统整体设计','',0,0,1,5,57,62,57,62,'11.1.1'),(11,51,'模块设计','',0,0,1,5,62,67,62,67,'11.1.2'),(11,52,'编制《系统设计与实现计划》','',0,0,1,3,67,70,67,70,'11.1.3'),(11,53,'编制《软件概要说明》','',0,0,1,3,70,73,70,73,'11.1.4'),(11,54,'系统实现','',1,0,1,17,73,90,73,90,'11.2'),(11,55,'编写代码','',0,0,1,7,73,80,73,80,'11.2.1'),(11,56,'代码自测','',0,0,1,4,80,84,80,84,'11.2.2'),(11,57,'单元测试','',0,0,1,3,84,87,84,87,'11.2.3'),(11,58,'集成测试','',0,0,1,3,87,90,87,90,'11.2.4'),(11,59,'系统设计与实现完成','',0,1,1,1,90,91,90,91,'12'),(11,60,'软件测试、部署、培训和维护','',1,0,1,9,91,100,91,100,'13'),(11,61,'编制《测试计划》','',0,0,1,2,91,93,91,93,'13.1'),(11,62,'编制《安装部署计划》','',0,0,1,3,93,96,93,96,'13.2'),(11,63,'编制《培训计划》','',0,0,1,2,96,98,96,98,'13.3'),(11,64,'编制《系统维护计划》','',0,0,1,2,98,100,98,100,'13.4'),(11,65,'软件测试、部署、培训和维护完成','',0,1,1,1,100,101,100,101,'14'),(11,66,'项目收尾','',1,0,1,7,101,108,101,108,'15'),(11,67,'答辩与评价','',0,0,1,2,101,103,101,103,'15.1'),(11,68,'经验总结','',0,0,1,2,103,105,103,105,'15.2'),(11,69,'编制《项目总结报告》','',0,0,1,3,105,108,105,108,'15.3'),(11,70,'项目完成','',0,1,1,1,108,109,108,109,'16'),(12,1,'Programming','Implement the three functions (30 pts.) and a testing program (20 pts.) with sufficient comments.',0,0,1,9,0,9,0,9,'1'),(12,2,'Testing','Decide the iteration number K for each test case and fill in the table of results (8 pts.).  Plot the run times of the functions (12 pts.).  Write analysis and comments (10 pts.).',0,0,1,9,0,9,0,9,'2'),(12,3,'Report Writing','Write Chapter 1 (6 pts.), Chapter 2 (12 pts.), and finally a complete report (2 pts. for overall style of documentation).',0,0,1,5,9,14,9,14,'3'),(13,1,'Programming','Write the program (50 pts.) with sufficient comments.',0,0,1,9,0,9,0,9,'1'),(13,2,'Testing','Provide a set of test cases to fill in a test report (20 pts.).  Note that the tester is responsible, as well as the programmer is, for any bug later found by Judge.  Write analysis and comments (10 pts.).',0,0,1,9,0,9,0,9,'2'),(13,3,'Report Writing','Write Chapter 1 (6 pts.), Chapter 2 (12 pts.), and finally a complete report (2 pts. for overall style of documentation).',0,0,1,5,9,14,9,14,'3'),(14,1,'Programming','Write the program (50 pts.) with sufficient comments.',0,0,1,9,0,9,0,9,'1'),(14,2,'Testing','Provide a set of test cases to fill in a test report (20 pts.).  Note that the tester is responsible, as well as the programmer is, for any bug later found by Judge.  Write analysis and comments (10 pts.).',0,0,1,9,0,9,0,9,'2'),(14,3,'Report Writing','Write Chapter 1 (6 pts.), Chapter 2 (12 pts.), and finally a complete report (2 pts. for overall style of documentation).',0,0,1,5,9,14,9,14,'3'),(15,1,'Programming',' Implement all the necessary operations on unbalanced binary search trees, AVL trees, and splay trees (6 pts.).  Write a test of performance program (3 pts.).  All the codes must be sufficiently commented.',0,0,1,7,0,7,0,7,'1'),(15,2,'Testing','Provide the necessary inputs for testing and give the run time table (2 pts.).  Plot the run times vs. input sizes for illustration (2 pts.).  Write analysis and comments (3 pts.).',0,0,1,7,0,7,0,7,'2'),(15,3,'Documentation Writing','Chapter 1 (1 pt.), Chapter 2 (2 pts.), and finally a complete report (1 point for overall style of documentation).',0,0,1,5,7,12,7,12,'3'),(15,4,'Make presentation','',0,0,1,2,12,14,12,14,'4'),(16,1,'Programming','Write the program (10 pts.) with sufficient comments.',0,0,1,7,0,7,0,7,'1'),(16,2,'Testing',')Provide a set of test cases to fill in a test report (3 pts.).  Write analysis and comments (3 pts.).',0,0,1,7,0,7,0,7,'2'),(16,3,'Documentation Writing','Chapter 1 (1 pt.), Chapter 2 (2 pts.), and finally a complete report (1 point for overall style of documentation).',0,0,1,5,7,12,7,12,'3'),(16,4,'Make presentation','',0,0,1,2,12,14,12,14,'4'),(17,1,'Introduction','Describe B-tree and its operations (8 pts.).',0,0,1,5,0,5,0,5,'1'),(17,2,'Analysis','Write analysis and comments on B- trees and B+ trees (9 pts.).',0,0,1,5,5,10,5,10,'2'),(17,3,'Documentation Writing','Combine all the chapters into a complete report (1 point for overall style of documentation).',0,0,1,2,10,12,10,12,'3'),(17,4,'Make presentation','',0,0,1,2,12,14,12,14,'4');
/*!40000 ALTER TABLE `tasks` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `user_instance`
--

DROP TABLE IF EXISTS `user_instance`;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
CREATE TABLE `user_instance` (
  `userid` int(11) NOT NULL,
  `instanceid` int(11) NOT NULL,
  `rolegroup` int(11) NOT NULL COMMENT '1==pm,2==nomal player,3==indicator,4==observer',
  `accepttime` datetime NOT NULL,
  `isvalid` tinyint(1) NOT NULL,
  PRIMARY KEY  (`userid`,`instanceid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci ROW_FORMAT=COMPACT;
SET character_set_client = @saved_cs_client;

--
-- Dumping data for table `user_instance`
--

LOCK TABLES `user_instance` WRITE;
/*!40000 ALTER TABLE `user_instance` DISABLE KEYS */;
INSERT INTO `user_instance` VALUES (3,1,1,'2010-07-05 10:55:13',1);
/*!40000 ALTER TABLE `user_instance` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `userinsrole`
--

DROP TABLE IF EXISTS `userinsrole`;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
CREATE TABLE `userinsrole` (
  `userId` int(10) NOT NULL,
  `insId` int(10) NOT NULL,
  `roleId` int(10) NOT NULL,
  `status` int(10) NOT NULL,
  `applyTime` datetime NOT NULL,
  `handleTime` datetime NOT NULL,
  PRIMARY KEY  (`userId`,`insId`,`roleId`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
SET character_set_client = @saved_cs_client;

--
-- Dumping data for table `userinsrole`
--

LOCK TABLES `userinsrole` WRITE;
/*!40000 ALTER TABLE `userinsrole` DISABLE KEYS */;
/*!40000 ALTER TABLE `userinsrole` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `users`
--

DROP TABLE IF EXISTS `users`;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
CREATE TABLE `users` (
  `uid` int(10) unsigned NOT NULL auto_increment,
  `username` varchar(255) collate utf8_unicode_ci NOT NULL,
  `password` varchar(255) collate utf8_unicode_ci NOT NULL,
  `groupid` int(10) NOT NULL,
  `sex` tinyint(1) default NULL,
  `registertime` datetime NOT NULL,
  `portraitpath` varchar(255) collate utf8_unicode_ci default NULL,
  `interests` varchar(255) collate utf8_unicode_ci default NULL,
  `signature` varchar(255) collate utf8_unicode_ci default NULL,
  `qq` varchar(255) collate utf8_unicode_ci default NULL,
  `msn` varchar(255) collate utf8_unicode_ci default NULL,
  `email` varchar(255) collate utf8_unicode_ci NOT NULL,
  `homepage` varchar(255) collate utf8_unicode_ci default NULL,
  `unreadedmessages` int(10) unsigned NOT NULL,
  `finisheds` int(10) unsigned NOT NULL,
  `ongoings` int(10) unsigned NOT NULL,
  `onlinetime` bigint(20) default NULL,
  `score` int(32) default NULL COMMENT '用户在系统中的积分',
  `status` tinyint(1) NOT NULL,
  PRIMARY KEY  (`uid`)
) ENGINE=InnoDB AUTO_INCREMENT=9 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci ROW_FORMAT=DYNAMIC;
SET character_set_client = @saved_cs_client;

--
-- Dumping data for table `users`
--

LOCK TABLES `users` WRITE;
/*!40000 ALTER TABLE `users` DISABLE KEYS */;
INSERT INTO `users` VALUES (1,'admin','21232f297a57a5a743894a0e4a801fc3',0,NULL,'2009-10-28 11:11:56',NULL,NULL,NULL,NULL,NULL,'admin@163.com',NULL,0,0,0,4553,999,0),(3,'user','ee11cbb19052e40b07aac0ca060c23ee',2,NULL,'2009-10-28 11:11:56','',NULL,NULL,NULL,NULL,'user@163.com',NULL,0,10,0,67096,666,1),(6,'wmc','c4ca4238a0b923820dcc509a6f75849b',2,1,'2009-10-28 11:11:56',NULL,'programming','wmc','282743146',NULL,'wmc@163.com',NULL,1,55,0,6779,999,1),(7,'wsn','c4ca4238a0b923820dcc509a6f75849b',2,NULL,'0000-00-00 00:00:00',NULL,NULL,NULL,NULL,NULL,'wsn@163.com',NULL,0,0,0,720,NULL,0),(8,'yangcheng','202cb962ac59075b964b07152d234b70',2,NULL,'2010-07-05 14:15:19',NULL,NULL,NULL,NULL,NULL,'yangcheng@cs.zju.edu.cn',NULL,0,0,0,1748,10,0);
/*!40000 ALTER TABLE `users` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2010-08-10 15:46:25
